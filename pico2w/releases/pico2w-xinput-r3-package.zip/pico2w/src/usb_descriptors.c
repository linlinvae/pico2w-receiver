// SPDX-License-Identifier: Apache-2.0
#include "tusb.h"
#include "pico/unique_id.h"
#include "usb_descriptors.h"
#include <string.h>
/* Wired XUSB subtype 1, defined by MS-XUSBI. Same working endpoint layout as
 * this project's CH582F receiver, now with a dedicated TinyUSB class driver. */
const uint8_t xinput_configuration[49] = {
    9,2,49,0,1,1,0,0x80,125, /* 250 mA configured budget for radio + MCU */
    9,4,0,0,2,0xff,0x5d,1,2,
    17,0x21,0,1,1,0x21,XINPUT_EP_IN,20,0,0,0,0,0x11,XINPUT_EP_OUT,8,0,0,
    7,5,XINPUT_EP_IN,3,32,0,4,
    7,5,XINPUT_EP_OUT,3,32,0,8,
};
const uint8_t xinput_compatible_id[40] = {
    40,0,0,0,0,1,4,0,1,0,0,0,0,0,0,0,
    0,1,'X','U','S','B','1','0',0,0,
    0,0,0,0,0,0,0,0,
    0,0,0,0,0,0
};
static const uint8_t ms_string[18] __attribute__((aligned(2))) = {
    18,3,'M',0,'S',0,'F',0,'T',0,'1',0,'0',0,'0',0,XINPUT_VENDOR_CODE,0
};
static const tusb_desc_device_t device = {
    .bLength = sizeof(tusb_desc_device_t), .bDescriptorType = TUSB_DESC_DEVICE,
    .bcdUSB = 0x0200, .bMaxPacketSize0 = 64, .idVendor = 0x2e8a,
    .idProduct = 0x10c7, .bcdDevice = 0x0100, .iManufacturer = 1,
    .iProduct = 2, .iSerialNumber = 3, .bNumConfigurations = 1,
};
uint8_t const *tud_descriptor_device_cb(void) { return (const uint8_t *)&device; }
uint8_t const *tud_descriptor_configuration_cb(uint8_t index) {
    return index == 0 ? xinput_configuration : NULL;
}
uint16_t const *tud_descriptor_string_cb(uint8_t index, uint16_t langid) {
    (void)langid;
    static uint16_t text[64];
    static char serial[PICO_UNIQUE_BOARD_ID_SIZE_BYTES * 2 + 1];
    const char *s;
    if (index == 0xee) return (const uint16_t *)ms_string;
    if (index == 0) { text[0] = 0x0304; text[1] = 0x0409; return text; }
    if (index == 1) s = "Local Receiver Project";
    else if (index == 2) s = "Pico 2 W XInput R3";
    else if (index == 3) {
        if (!serial[0]) pico_get_unique_board_id_string(serial, sizeof(serial));
        s = serial;
    } else return NULL;
    unsigned n = (unsigned)strlen(s); if (n > 63) n = 63;
    text[0] = (uint16_t)(0x0300 | (n * 2 + 2));
    for (unsigned i = 0; i < n; ++i) text[i + 1] = (uint8_t)s[i];
    return text;
}
