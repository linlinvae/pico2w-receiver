#ifndef RECEIVER_PLATFORM_H
#define RECEIVER_PLATFORM_H
struct uni_platform *receiver_platform(void);
#endif
