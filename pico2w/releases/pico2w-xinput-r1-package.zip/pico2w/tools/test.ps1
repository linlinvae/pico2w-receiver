param([string]$Gcc='gcc')
$ErrorActionPreference='Stop'
$root=Split-Path $PSScriptRoot -Parent
New-Item -ItemType Directory -Force "$root/tests/build" | Out-Null
$flags=@('-std=c11','-Wall','-Wextra','-Werror',"-I$root/src")
& $Gcc @flags "$root/src/bridge.c" "$root/tests/test_bridge.c" -o "$root/tests/build/test_bridge.exe"
if($LASTEXITCODE -ne 0) {throw 'Bridge test compilation failed'}
& "$root/tests/build/test_bridge.exe"
if($LASTEXITCODE -ne 0) {throw 'Bridge tests failed'}
& $Gcc @flags -DCFG_TUSB_MCU=OPT_MCU_RP2040 "-I$root/tests/stubs" "-I$root/resources/pico-sdk/lib/tinyusb/src" `
    "$root/src/bridge.c" "$root/src/usb_xinput.c" "$root/src/usb_descriptors.c" "$root/tests/test_usb.c" `
    -o "$root/tests/build/test_usb.exe"
if($LASTEXITCODE -ne 0) {throw 'USB test compilation failed'}
& "$root/tests/build/test_usb.exe"
if($LASTEXITCODE -ne 0) {throw 'USB tests failed'}
