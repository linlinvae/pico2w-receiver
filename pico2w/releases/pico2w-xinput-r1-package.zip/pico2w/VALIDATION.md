# R1 交付验证（2026-10-10）

- 目标：`pico2_w` / `rp2350-arm-s`，Cortex-M33，Release。
- ARM GNU 14.2.Rel1 编译链接通过；应用及最终重编译无编译器警告。SDK 配置阶段提示未初始化 lwIP；R1 不启用 Wi-Fi，Bluetooth 构建支持已启用。
- Bluepad32、BTstack、Pico SDK、TinyUSB、CYW43、mbedTLS 六个固定源码提交校验通过，供应商源码无跟踪文件修改。
- 8862 次 bridge 检查通过：轴端点/方向/单调性、模拟和数字扳机、按钮位置、支持身份与错误协议拒绝、断线释放、连接正常无新输入时保留按住状态、停止优先、USB 休眠/复位后的震动清除。
- 102 次 USB 检查通过：真实 TinyUSB 头文件下的应用类驱动、描述符与 OS Compatible ID、GET_REPORT/SET_REPORT、短包拒收、IN 忙时不覆盖缓存、中立报告优先、失败重试、OUT 重新挂接、挂起/恢复/复位。
- `setup.ps1` 与 `build.ps1` 在当前 Windows 工作区执行成功；编译工具安装在本项目中。
- 官方 picotool 识别 UF2 为 RP2350 ARM Secure，名称/版本/板型正确。
- UF2 含 2028 个连续应用块和 1 个官方 ROM-ignore 块；应用写入范围 `0x10000000..0x1007EC00`，未触及配对 Flash banks。链接阶段也检查 Flash 上限。
- 静态段：text 523104 bytes，data 0，bss 43300；BIN 519008 bytes，UF2 1038848 bytes。
- UF2 SHA256：`C837ACFD15A004F5A57F00949EEEA9F3CCB3F2E6263F557E2F400B068358388C`。
- 原 Stadia / Switch Pro 工程 192 个文件哈希与保留清单一致；原 receiver 的 121 个文件同时符合之前建立的清单。

**待实物验证**：Pico 2 W 上三种手柄的配对/重连、Windows XInput 自动绑定、真实按钮与摇杆、模拟扳机、双马达及停止、运行中 BOOTSEL 长按清配对、USB 拔插/休眠和实际蓝牙断线释放时间。未烧录用户硬件，未读取串口。

主机检查通过表示逻辑与协议布局符合这些测试，不能代替真实射频、手柄固件及 Windows 驱动验证。首次建议仅打开 XSX 手柄测试，完成后再换 Switch Pro 与 Stadia。
