# R4.1 交付验证（2026-10-10）

只读检查用户已插入的 R4 硬件：复合设备及 XInput MI_00 状态OK；电量HID MI_01报Code10 / 0xC00000B9，Windows明确报告“声明了一个非常量主项目，但是未提供相应的用法。”这是实际设备枚举证据。

- 修复 Input 主项目缺少局部 Usage；HID报告描述符27字节，接口声明长度与编译期断言一致。
- 8862 bridge、136 USB、59 battery、7工具协议、183平台和87 BLE检查通过。新增主项目局部 Usage 生命周期测试拒绝旧R4描述符，接受修正描述符及合法常量填充，拒绝截断字段。旧TinyUSB测试只检查传输，不会执行Windows HID语义解析，因此未发现此问题。
- ARM Release编译链接通过，无warning/error；text530632、data0、bss43700 bytes。构建记录与源码、工具、测试、产物逐项SHA256匹配。
- BIN中确认存在修正后的27字节报告及对应HID接口长度；UF2 2057个应用块+1个官方ROM-ignore块，应用写入范围0x10000000..0x10080900，未触及配对区。
- 六个固定依赖无跟踪修改，原工程192项及R1/R2/R3/R4每版五项产物哈希保持一致。
- R4.1 UF2 SHA256：`93B14A210A65E591D22E18AD5F6E17001868BBEABDCE027BDBC24D3607AB772E`。

未自动刷机或修改Windows驱动。修正后HID实际启动及Feature电量读取待刷入复测；现有电量工具可继续使用，2ms输入和蓝牙逻辑没有改变。

## R4 原交付验证（2026-10-10）

保留用户确认可用的 R3，新增 USB 2 ms 输入与电量查看。继续单手柄；R4 实物测试待用户执行。

- 8862 次 bridge、131 次 USB、59 次电量客户端、7 次 Windows 电量工具协议、183 次平台、87 次 BLE 发现检查通过；平台仍包含三种手柄 15 次模拟回连，BLE 发现仍含 50 次已配对广播唤醒。
- USB 测试链接固定 TinyUSB HID 实现，实际执行 HID 接口打开、Feature GET_REPORT（含 Report ID 插入）和报告描述符请求；验证 74 字节双接口配置、XUSB 2 ms IN、8 ms OUT、1 ms 不发送/2 ms 发送、忙缓存与中立报告优先。
- 电量测试执行实际应用模块，模拟 Battery Service 回调，检查启动延迟、0% 有效、100%、非法值/旧 CID 拒绝、每30秒读取、120秒过期、断开清空、失败客户端释放、五档及充电标志、短报告/其他手柄拒绝、Xbox HID 原始范围。BLE 无线与 GATT 服务端没有实物仿真。
- Windows PowerShell 5.1 编译工具的 C# 原生 HID/SetupAPI 声明并执行协议自测，无 USB 设备访问；未实际运行硬件 HID 枚举/读取。
- ARM 编译链接无 warning/error，目标 Pico 2 W / RP2350 ARM Secure，picotool 确认 R4.0。ELF 包含三个应用包装和静态 Battery Service 客户端池；没有 Core1 启动符号。
- UF2 2057 个应用块 + 1 个官方 ROM-ignore 块，写入范围 0x10000000..0x10080900，配对 Flash 区没有触及；text 530640、data 0、bss 43700 bytes。
- UF2 1053696 bytes，BIN 526544 bytes；源码/工具/测试和产物 SHA256 与构建记录逐项一致。
- 六个固定源码依赖无跟踪修改，原工程192个哈希通过，R1/R2/R3 各5个固件及交付产物哈希通过。
- R4 UF2 SHA256：`C3C7614AB12D6242A34D4A9F7F4371324C7E8CFCA4232E454EFAFC37FF24B06E`。

未自动烧录、读取串口或开启双手柄。Windows 新 PID 10C8 的复合接口枚举、XInput 自动绑定、三种手柄实际电量、回连及 USB 总线实际500Hz需要上板验证。USB设置为2ms不等于蓝牙端到端延迟为2ms，也不是已实测500Hz。

## R3 原交付验证（2026-10-10）

用户确认 R2 的 Switch Pro、XSX 自动回连正常；Stadia 关闭再开机时接收器 LED 一直慢闪，插拔接收器后才恢复。R3 针对 BLE 广播发现修复，用户后续已确认 Stadia 自动回连成功。

- 目标 `pico2_w` / `rp2350-arm-s`，Cortex-M33，Release，Pico SDK 2.2.0，ARM GNU 14.2.Rel1。构建链接通过，构建日志无编译器 warning/error。
- 8862 次 bridge、102 次 USB、183 次平台生命周期检查通过；平台检查确认主动扫描配置、BLE 就绪后缓存刷新和清配对时缓存清除，原三种手柄 15 次模拟重连仍通过。
- 87 次 BLE 广播检查通过，包括 50 次已配对地址的空/定向广播唤醒、地址类型匹配、稀疏 LE 数据库、主动扫描响应中的 Stadia 名称、普通 HID、发现门控、畸形包拒收、最大长度与原始缓冲区不修改。
- BLE 回放使用固定 Bluepad32 发现函数及其三个辅助函数的原文，未重写原解析逻辑。原函数拒绝已配对地址的空定向广播，而 R3 应用包装后发起连接。这是广播发现层验证；没有模拟完整配对加密/GATT/HID 链路，也没有捕获用户设备的真实广播。
- ARM ELF 中同时保留原发现函数和应用包装；反汇编确认 `uni_bt_packet_handler` 的广播入口转到应用包装，包装继续调用原函数。
- 六个固定依赖源码无跟踪文件修改；原工程 192 个哈希通过；R1、R2 的 UF2/BIN/ELF/构建记录/ZIP 各五个产物哈希通过。
- picotool 识别版本 R3.0，Pico 2 W，RP2350 ARM Secure；UF2 包含 2035 个连续应用块、1 个官方 ROM-ignore 块，应用范围 `0x10000000..0x1007F300`，未触及配对区，链接 Flash 上限检查通过。
- text 524960 bytes，data 0，bss 43432；BIN 520864 bytes，UF2 1042432 bytes。
- R3 UF2 SHA256：`07DABCEC600A04D03192E2F8F2B4A94453691BB79B1FC7CED25652DA381BFA76`。

未自动烧录或读取串口；R3 未清除用户配对记录。优先用原记录测试 Stadia 开机连接，然后保持接收器插入，关机、等接收器 LED 慢闪、正常开机，重复 5 次。再检查 Xbox/Switch 回连和三种手柄切换。

## R2 原交付验证记录（2026-10-10）

用户实测反馈：R1 的 XSX、Switch Pro、Stadia 连接和输入正常；三个手柄关闭再开机均不能自动回连，插拔接收器后恢复。R2 针对共用连接恢复流程修复。后续用户确认 Switch Pro、XSX 回连正常，Stadia 仍失败；上方 R3 继续处理。

- 目标 `pico2_w` / `rp2350-arm-s`，Cortex-M33，Release，Pico SDK 2.2.0，ARM GNU 14.2.Rel1。构建链接通过，构建日志无编译器 warning/error。
- 8862 次 bridge、102 次 USB 检查通过；181 次平台连接生命周期检查通过，包括三种手柄共 15 次模拟断开重连。
- 新测试使用固定 Bluepad32 / BTstack 的真实头文件、真实 `platform.c` 与模拟无线状态，检查异步取消后搜索重试、实际扫描与软件状态失同步、配对中的设备槽、漏掉断线回调、失效 HCI 连接、保持按住的输入、BOOTSEL 操作。提取保留的 R1 平台源码运行同一测试，失败于断线回调内立即扫描的检查；R2 通过。
- 六个固定依赖源码无跟踪文件修改；原 Stadia / Switch Pro 工程 192 个哈希通过，R1 UF2/BIN/ELF/构建记录和 ZIP 五个产物哈希通过。
- picotool 识别名称为 Pico 2 W XInput Receiver，版本 R2.0，Pico 2 W，RP2350 ARM Secure。
- UF2 包含 2030 个连续应用块、1 个官方 ROM-ignore 块，应用范围 `0x10000000..0x1007EE00`，配对存储区未触及，链接 Flash 上限检查通过。
- text 523704 bytes，data 0，bss 43316；BIN 519608 bytes，UF2 1039872 bytes。
- R2 UF2 SHA256：`7D865C13E75F2CE420B8224EA8FDE0EFC3E45997A102001E3F4E3CE194F4F6A1`。

未自动烧录或读取串口。实测请保持接收器插入，每种手柄关机后等 LED 慢闪，再正常开机，重复 5 次；随后测试三种手柄交替连接。保存配对记录不因本次 UF2 更新而清除。没有实物日志，代码中的恢复缺口及模拟测试不能证明它们就是用户设备上唯一的触发原因。

## R1 原交付验证记录（2026-10-10）

- 目标：`pico2_w` / `rp2350-arm-s`，Cortex-M33，Release。
- ARM GNU 14.2.Rel1 编译链接通过；应用及最终重编译无编译器警告。SDK 配置阶段提示未初始化 lwIP；R1 不启用 Wi-Fi，Bluetooth 构建支持已启用。
- Bluepad32、BTstack、Pico SDK、TinyUSB、CYW43、mbedTLS 六个固定源码提交校验通过，供应商源码无跟踪文件修改。
- 8862 次 bridge 检查通过：轴端点/方向/单调性、模拟和数字扳机、按钮位置、支持身份与错误协议拒绝、断线释放、连接正常无新输入时保留按住状态、停止优先、USB 休眠/复位后的震动清除。
- 102 次 USB 检查通过：真实 TinyUSB 头文件下的应用类驱动、描述符与 OS Compatible ID、GET_REPORT/SET_REPORT、短包拒收、IN 忙时不覆盖缓存、中立报告优先、失败重试、OUT 重新挂接、挂起/恢复/复位。
- `setup.ps1` 与 `build.ps1` 在当前 Windows 工作区执行成功；编译工具安装在本项目中。
- 官方 picotool 识别 UF2 为 RP2350 ARM Secure，名称/版本/板型正确。
- UF2 含 2028 个连续应用块和 1 个官方 ROM-ignore 块；应用写入范围 `0x10000000..0x1007EC00`，未触及配对 Flash banks。链接阶段也检查 Flash 上限。
- 静态段：text 523104 bytes，data 0，bss 43300；BIN 519008 bytes，UF2 1038848 bytes。
- UF2 SHA256：`C837ACFD15A004F5A57F00949EEEA9F3CCB3F2E6263F557E2F400B068358388C`。
- 原 Stadia / Switch Pro 工程 192 个文件哈希与保留清单一致；原 receiver 的 121 个文件同时符合之前建立的清单。

**R1 交付时的待验证项（历史记录）**：Pico 2 W 上三种手柄的配对/重连、Windows XInput 自动绑定、真实按钮与摇杆、模拟扳机、双马达及停止、运行中 BOOTSEL 长按清配对、USB 拔插/休眠和实际蓝牙断线释放时间。用户后续确认三种手柄连接和输入正常，并报告本次处理的回连失败。未自动烧录用户硬件，未读取串口。

主机检查通过表示逻辑与协议布局符合这些测试，不能代替真实射频、手柄固件及 Windows 驱动验证。首次建议仅打开 XSX 手柄测试，完成后再换 Switch Pro 与 Stadia。
