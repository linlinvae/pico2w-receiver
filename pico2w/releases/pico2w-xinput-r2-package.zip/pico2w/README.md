# Pico 2 W 三合一 XInput 接收器 R2

独立实验固件：使用 Pico 2 W 接收一只蓝牙手柄，通过板载 Micro-USB 向 Windows 输出一个 wired XUSB / XInput 控制器。无需 CH582F、ESP32 或外接模块。`receiver/` 和 `switchpro/` 的原固件保留。

**用户已确认 R1 三种手柄连接和输入正常，但三个手柄关机再开机均无法回连，需插拔接收器。R2 修复共用连接恢复流程，已通过主机回归测试、ARM 编译与 UF2 校验；真实自动回连仍待用户上板复测。** 震动、清配对等功能尚无专项实测结论。R1 固件及交付压缩包原样保留。

R2 将恢复扫描推迟到断线清理之后；空闲时每 2 秒确认允许连接并重新请求 BLE 扫描、重试经典蓝牙搜索，绕过“扫描已开启”软件标志造成的空返回；检查已失效的设备槽并释放旧输入。配对或正常连接期间不执行空闲扫描修复，不按输入报告的静默时间判定断线。详见 `CHANGELOG.md`。

## 兼容基线

| 手柄 | 无线协议 | 接受范围 | 输入与震动 |
|---|---|---|---|
| Xbox Series X/S 原装手柄 | BLE HID | Microsoft VID `045E`、PID `0B13`，Xbox One/Series 解析器；以型号 1914 为目标 | 按键、双摇杆、独立模拟 LT/RT、双马达 |
| 第一代 Switch Pro 原装手柄 | Bluetooth BR/EDR HID | Nintendo `057E:2009`，Switch Pro 解析器 | 按键、双摇杆、数字 ZL/ZR、双通道震动转换 |
| Google Stadia | BLE HID | Google `18D1:9400`，已启用蓝牙模式 | 按键、双摇杆、独立模拟 LT/RT、双马达 |

XSX 以 Bluepad32 文档中的 BLE 固件基线为依据，用户手柄的实际固件版本尚未检查。固件严格限制上述身份，未加入 Xbox 专有无线、Xbox 360 无线、第三方仿制手柄或 Switch 2 Pro。

一次连接一只手柄。三种协议在同一固件内自动识别，无需选择模式。按键按位置映射为 Xbox：Switch 的 B→A、A→B、Y→X、X→Y；Minus→Back、Plus→Start、Home→Guide。Capture/Share/Assistant 暂不映射。XInput 传输不包含陀螺仪、NFC、音频或 Xbox 扳机马达；目标是 Windows PC。

## 刷机

1. 使用带数据传输功能的 Micro-USB 线。按住板上 **BOOTSEL**，插到电脑，再松开。
2. 打开出现的 **RP2350** 磁盘，将 `firmware/pico2w-xinput-r2.uf2` 拖入。磁盘消失、开发板重启。
3. 启动后板载 LED 慢闪表示等待连接，常亮表示手柄已就绪。没有手柄时电脑仍能看到一个输入为零的 USB 控制器。
4. 让一只目标手柄进入配对状态，其他手柄先关机。XSX：长按顶部配对键到 Xbox 灯快闪；Switch Pro：长按 USB-C 旁的 SYNC；Stadia：在已启用蓝牙模式的手柄上按住 Y + Stadia 到橙灯闪烁。
5. 连接后执行 `Win + R` → `joy.cpl`，再在游戏或手柄测试页检查输入。

第一次配对需要进入手柄配对模式。接收器保存经典蓝牙与 BLE 密钥，正常拔插和再次刷本项目的 UF2 不删除它们。手柄切到其他主机后可能需要再次进入配对模式；这也取决于手柄自身保存的配对记录。

切换类型：关闭当前手柄，等待 LED 恢复慢闪，再打开或配对另一只。单连接版本会连接先就绪的手柄，测试时只打开目标手柄。

运行中短按 BOOTSEL：未连接时重新启动扫描。**运行中长按 BOOTSEL 至少 3 秒，然后松开：停止无线、清除本接收器保存的所有配对记录、自动重启。** 长按时 LED 快闪；需要松开才重启，以免进入 ROM 刷机模式。插电时按住 BOOTSEL 的作用仍然是进入刷机磁盘。

## 实物验证顺序

**R2 优先复测**：接收器保持插在电脑上，每次仅打开一只手柄。连接后关闭手柄，等接收器 LED 恢复慢闪，再按手柄正常开机键，检查无需再次进入配对模式即可连接、输入恢复。XSX、Switch Pro、Stadia 各重复 5 次，再交替切换三种手柄。先使用原保存的配对记录；升级本项目 UF2 不清除记录。若失败，记录手柄型号和 LED 是否恢复慢闪、是否重新常亮、关机后等待时间；不需要读取串口。

先测 XSX，再测 Switch Pro、Stadia；每种都检查：配对、A/B/X/Y 与十字键、双摇杆方向和中心、LT/RT、震动停止、按住按键时关闭手柄后的释放、接收器拔插后的重新连接。传统 `joy.cpl` 可能把 LT/RT 合并为 Z 轴，可用下面的 XInput 测试脚本分别检查。

```powershell
python .\pico2w\tools\test_windows.py --index 0 --seconds 30
# 用户主动执行此命令才测试震动；先确认 index 对应本接收器。
python .\pico2w\tools\test_windows.py --index 0 --seconds 20 --rumble
```

脚本列出 0–3 四个 XInput 槽位，输出独立扳机及摇杆数值；带 `--rumble` 时分别震动 0.7 秒并停止。脚本不读取串口。蓝牙断线释放以协议栈报告断链为准，受连接监督超时影响，不承诺固定毫秒数。连接正常但没有新报告时，固件保留按住状态。

如果 Windows 不识别为 Xbox 兼容设备，先记录设备管理器中的设备名称、错误码和硬件 ID `VID_2E8A&PID_10C7`。这是沿用本项目的开发身份；固件提供 `MSFT100` / `XUSB10` 兼容描述符，实际自动绑定仍需 Windows 实测。

## 构建与测试

所有下载、编译工具和构建产物均位于 `pico2w/`，不做全局安装，不自动烧录。Windows 需要 Git、Python 3，主机单元测试另需 GCC。

```powershell
.\pico2w\tools\setup.ps1
.\pico2w\tools\test.ps1 -Gcc gcc
.\pico2w\tools\build.ps1 -Python python
```

`dependencies.lock.json` 固定 SDK、Bluepad32、BTstack 和下载工具版本/哈希。构建前检查依赖无修改、旧工程及现有 R1 产物文件哈希，成功后生成 R2 UF2、BIN、ELF 和 `firmware/pico2w-xinput-r2-build-info.json`。`resources/`、`build/` 不属于交付源码，可通过 setup 重建。

独立解压到不包含旧工程的目录也可构建；此时旧文件保留审计不适用。当前工作区的旧工程已经执行完整哈希校验。

工程采用 Cortex-M33、单核前台 polling run loop。Bluetooth 与 `tud_task()` 在同一上下文处理，USB 中断仅交给 TinyUSB 入队；应用不使用动态分配。Pico SDK 的 `arch_none` 默认是后台中断上下文，本工程在应用 CMake 中替换 Bluepad32 的该链接依赖，改为 polling。BTstack 新版本将 `hids_client.c` 改名为 `hids_host.c`，应用 CMake 适配源文件列表，未修改供应商源码。

USB 输入周期 4 ms，输出端点 8 ms；这些是固件/USB 调度参数，不是实测端到端延迟。8 字节 XUSB 震动命令反向传给 Bluepad32。主机仅更新一次的持续震动会由固件每约 100 ms 刷新 250 ms 有限时长命令；零震动优先处理，USB 复位/休眠/卸载与手柄断线会清除震动状态。后续控制器不会继承旧震动。

Flash `0x3FD000..0x3FEFFF` 保留给 BTstack 的两个 4 KiB TLV bank；最后 4 KiB 保留给 RP2350 芯片勘误处理。链接断言和 UF2 检查阻止应用覆盖配对区。UF2 包含官方 picotool 生成的 ROM-ignore 兼容块；校验脚本单独检查该块。

## 来源与许可证

蓝牙实现使用 [Bluepad32](https://github.com/ricardoquesada/bluepad32)、[BTstack](https://github.com/bluekitchen/btstack)，板级/USB 使用 [Pico SDK 2.2.0](https://github.com/raspberrypi/pico-sdk/releases/tag/2.2.0) 与 TinyUSB。控制器资料见 [Bluepad32 支持列表](https://bluepad32.readthedocs.io/en/latest/supported_gamepads/)；[BetterJoy](https://github.com/davidobot/BetterJoy) 作为之前讨论的 Switch 协议参考，本工程未引入其 PC 驱动代码。USB 布局依据 [Microsoft MS-XUSBI](https://learn.microsoft.com/en-us/openspecs/windows_protocols/ms-xusbi/) 和原接收器已经工作的协议实现。

本工程原创应用代码采用 Apache-2.0。BOOTSEL 采样改编自 Raspberry Pi 的 BSD-3-Clause 示例。`licenses/` 包含相关许可证，`NOTICE.md` 记录归属；Pico 2 W 上的 BTstack/CYW43 使用范围以附带 Raspberry Pi 许可证为准。
