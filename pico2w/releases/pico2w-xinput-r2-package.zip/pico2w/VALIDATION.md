# R2 交付验证（2026-10-10）

用户实测反馈：R1 的 XSX、Switch Pro、Stadia 连接和输入正常；三个手柄关闭再开机均不能自动回连，插拔接收器后恢复。R2 针对共用连接恢复流程修复，真实回连效果待用户复测。

- 目标 `pico2_w` / `rp2350-arm-s`，Cortex-M33，Release，Pico SDK 2.2.0，ARM GNU 14.2.Rel1。构建链接通过，构建日志无编译器 warning/error。
- 8862 次 bridge、102 次 USB 检查通过；181 次平台连接生命周期检查通过，包括三种手柄共 15 次模拟断开重连。
- 新测试使用固定 Bluepad32 / BTstack 的真实头文件、真实 `platform.c` 与模拟无线状态，检查异步取消后搜索重试、实际扫描与软件状态失同步、配对中的设备槽、漏掉断线回调、失效 HCI 连接、保持按住的输入、BOOTSEL 操作。提取保留的 R1 平台源码运行同一测试，失败于断线回调内立即扫描的检查；R2 通过。
- 六个固定依赖源码无跟踪文件修改；原 Stadia / Switch Pro 工程 192 个哈希通过，R1 UF2/BIN/ELF/构建记录和 ZIP 五个产物哈希通过。
- picotool 识别名称为 Pico 2 W XInput Receiver，版本 R2.0，Pico 2 W，RP2350 ARM Secure。
- UF2 包含 2030 个连续应用块、1 个官方 ROM-ignore 块，应用范围 `0x10000000..0x1007EE00`，配对存储区未触及，链接 Flash 上限检查通过。
- text 523704 bytes，data 0，bss 43316；BIN 519608 bytes，UF2 1039872 bytes。
- R2 UF2 SHA256：`7D865C13E75F2CE420B8224EA8FDE0EFC3E45997A102001E3F4E3CE194F4F6A1`。

未自动烧录或读取串口。实测请保持接收器插入，每种手柄关机后等 LED 慢闪，再正常开机，重复 5 次；随后测试三种手柄交替连接。保存配对记录不因本次 UF2 更新而清除。没有实物日志，代码中的恢复缺口及模拟测试不能证明它们就是用户设备上唯一的触发原因。

## R1 原交付验证记录（2026-10-10）

- 目标：`pico2_w` / `rp2350-arm-s`，Cortex-M33，Release。
- ARM GNU 14.2.Rel1 编译链接通过；应用及最终重编译无编译器警告。SDK 配置阶段提示未初始化 lwIP；R1 不启用 Wi-Fi，Bluetooth 构建支持已启用。
- Bluepad32、BTstack、Pico SDK、TinyUSB、CYW43、mbedTLS 六个固定源码提交校验通过，供应商源码无跟踪文件修改。
- 8862 次 bridge 检查通过：轴端点/方向/单调性、模拟和数字扳机、按钮位置、支持身份与错误协议拒绝、断线释放、连接正常无新输入时保留按住状态、停止优先、USB 休眠/复位后的震动清除。
- 102 次 USB 检查通过：真实 TinyUSB 头文件下的应用类驱动、描述符与 OS Compatible ID、GET_REPORT/SET_REPORT、短包拒收、IN 忙时不覆盖缓存、中立报告优先、失败重试、OUT 重新挂接、挂起/恢复/复位。
- `setup.ps1` 与 `build.ps1` 在当前 Windows 工作区执行成功；编译工具安装在本项目中。
- 官方 picotool 识别 UF2 为 RP2350 ARM Secure，名称/版本/板型正确。
- UF2 含 2028 个连续应用块和 1 个官方 ROM-ignore 块；应用写入范围 `0x10000000..0x1007EC00`，未触及配对 Flash banks。链接阶段也检查 Flash 上限。
- 静态段：text 523104 bytes，data 0，bss 43300；BIN 519008 bytes，UF2 1038848 bytes。
- UF2 SHA256：`C837ACFD15A004F5A57F00949EEEA9F3CCB3F2E6263F557E2F400B068358388C`。
- 原 Stadia / Switch Pro 工程 192 个文件哈希与保留清单一致；原 receiver 的 121 个文件同时符合之前建立的清单。

**R1 交付时的待验证项（历史记录）**：Pico 2 W 上三种手柄的配对/重连、Windows XInput 自动绑定、真实按钮与摇杆、模拟扳机、双马达及停止、运行中 BOOTSEL 长按清配对、USB 拔插/休眠和实际蓝牙断线释放时间。用户后续确认三种手柄连接和输入正常，并报告本次处理的回连失败。未自动烧录用户硬件，未读取串口。

主机检查通过表示逻辑与协议布局符合这些测试，不能代替真实射频、手柄固件及 Windows 驱动验证。首次建议仅打开 XSX 手柄测试，完成后再换 Switch Pro 与 Stadia。
